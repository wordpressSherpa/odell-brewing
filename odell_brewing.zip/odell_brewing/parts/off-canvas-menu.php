<aside class="right-off-canvas-menu" aria-hidden="true">
    <?php foundationPress_top_bar_r(); ?>
    
    <div class="mobile-secondary">
		<?php foundationPress_top_bar_l(); ?>
	</div>
	<div class="clear"></div>
	<div class="mobile-social-icons">
		<ul class="small-block-grid-4">
		<li><a href="https://www.facebook.com/ OdellBrewingCo" target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/icon_fb_mobile.png" alt="Odell's Facebook"></a></li>
		<li><a href="https://twitter.com/#!/OdellBrewing" target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/icon_twitter_mobile.png" alt="Odell's Twitter"></a></li>
		<li><a href="https://www.youtube.com/channel/ UCAzz9J7n4I2wS4KBbZ7XMtA" target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/icon_yt_mobile.png" alt="Odell's YouTube"></a></li>
		<li><a href="https://www.pinterest.com/ odellbrewing/"target="_blank"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icons/icon_pin_mobile.png" alt="Odell's Pinterest"></a></li>
		</ul>
	</div>
</aside>