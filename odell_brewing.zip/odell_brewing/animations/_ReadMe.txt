To add an animation to this site:

1) Upload the images for the animations into the "images" directory in the root of this install
2) Upload the JS file here into the "animations" directory
3) Update the file "functions/animation.php" from the root of the Odell theme
4) In the admin go to Custom Fields -> Page and update the options in the "select_animation" field group.